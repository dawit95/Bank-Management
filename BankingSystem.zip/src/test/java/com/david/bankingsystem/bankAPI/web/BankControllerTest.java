package com.david.bankingsystem.bankAPI.web;

import com.david.bankingsystem.bankAPI.domain.Account;
import com.david.bankingsystem.bankAPI.domain.AccountRepository;
import com.david.bankingsystem.bankAPI.domain.Transaction;
import com.david.bankingsystem.bankAPI.domain.TransactionRepository;
import com.david.bankingsystem.bankAPI.dto.RegisterRequestDto;
import com.david.bankingsystem.bankAPI.dto.TransferRequestDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * FileName : BankControllerTest
 * Author : David
 * Date : 2022-02-18
 * Description : 임시 뱅킹서비스 통합 테스트
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Transactional
public class BankControllerTest {
    @Autowired
    protected MockMvc mvc;

    @Autowired
    protected AccountRepository accountRepository;
    @Autowired
    protected TransactionRepository transactionRepository;

    @Autowired
    protected ObjectMapper objectMapper;

    @Test
    @DisplayName("계좌 등록 성공")
    public void RegisterAccountSuccess() throws Exception {
        //given
        RegisterRequestDto requestDto = RegisterRequestDto.builder()
                .bank_code("D001")
                .bank_account_number("0123456789")
                .build();

        //when
        ResultActions resultActions = mvc.perform(
                post("/banking-api/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto))
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        Account accountResponse = accountRepository.findByBankCodeAndBankAccountNumber(requestDto.getBank_code(), requestDto.getBank_account_number()).orElse(new Account());
        resultActions
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("bank_account_id").value(accountResponse.getBankAccountId()));

    }

    @Test
    @DisplayName("계좌 등록 예외 400")
    public void RegisterAccountException400() throws Exception {
        //given
        RegisterRequestDto requestDto = RegisterRequestDto.builder()
                .bank_code("없는 은행 코드")
                .bank_account_number("0123456781")
                .build();

        //when
        ResultActions resultActions = mvc.perform(
                post("/banking-api/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto))
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        resultActions
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("code").value("BANKING_ERROR_100"))
                .andExpect(jsonPath("message").value("잘못된 계좌 정보"));

    }

    @Test
    @DisplayName("계좌 등록 예외 422")
    public void RegisterAccountException422() throws Exception {
        //given
        RegisterRequestDto requestDto = RegisterRequestDto.builder()
                .bank_code("D001")
                .bank_account_number("0123456789")
                .build();
        saveAccountOne();

        //when
        ResultActions resultActions = mvc.perform(
                post("/banking-api/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto))
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        resultActions
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("code").value("BANKING_ERROR_101"))
                .andExpect(jsonPath("message").value("등록할 수 없는 계좌"));

    }

    @Test
    @DisplayName("계좌 이체 성공")
    public void TransferAccountSuccess() throws Exception {
        //given
        saveAccountTwo();
        TransferRequestDto requestDto = TransferRequestDto.builder()
                .tx_id("11223344")
                .from_bank_account_id("00000001")
                .to_bank_code("D002")
                .to_bank_account_number("9876543210")
                .transfer_amount(1000L)
                .build();

        //when
        ResultActions resultActions = mvc.perform(
                post("/banking-api/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto))
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        Transaction transaction = transactionRepository.findByTxId(requestDto.getTx_id()).orElse(new Transaction());
        resultActions
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("tx_id").value(transaction.getTxId()))
                .andExpect(jsonPath("bank_tx_id").value(transaction.getBankTxId()))
                .andExpect(jsonPath("result").value(transaction.getResult()));

    }


    @Test
    @DisplayName("계좌 이체 예외 400")
    public void TransferAccountException400() throws Exception {
        //given
        TransferRequestDto requestDto = TransferRequestDto.builder()
                .tx_id("11223344")
                //없는 계좌 ID
                .from_bank_account_id("00000003")
                .to_bank_code("D002")
                .to_bank_account_number("9876543210")
                .transfer_amount(1000L)
                .build();
        saveAccountTwo();

        //when
        ResultActions resultActions = mvc.perform(
                post("/banking-api/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto))
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        resultActions
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("code").value("BANKING_ERROR_200"))
                .andExpect(jsonPath("message").value("등록되지 않은 계좌 ID"));

    }

    @Test
    @DisplayName("계좌 이체 예외 422")
    public void TransferAccountException422() throws Exception {
        //given
        saveAccountTwo();
        TransferRequestDto requestDto = TransferRequestDto.builder()
                .tx_id("11223344")
                .from_bank_account_id("00000001")
                .to_bank_code("D002")
                .to_bank_account_number("9876543210")
                .transfer_amount(500000000L)
                .build();

        //when
        ResultActions resultActions = mvc.perform(
                post("/banking-api/transfer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDto))
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        resultActions
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("code").value("BANKING_ERROR_202"))
                .andExpect(jsonPath("message").value("계좌 잔액 부족"));
    }

    @Test
    @DisplayName("계좌 거래내역 조회 성공")
    public void TransferInfoSuccess() throws Exception {
        //given
        Transaction transaction = Transaction.builder()
                .txId("11223344")
                .bankTxId("12345678")
                .result("SUCCESS")
                .build();
        transactionRepository.save(transaction);


        //when
        ResultActions resultActions = mvc.perform(
                get("/banking-api/transfer/11223344")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        resultActions
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("result").value(transaction.getResult()));
    }

    @Test
    @DisplayName("계좌 거래내역 조회 예외 400")
    public void TransferInfoException400() throws Exception {
        //given
        Transaction transaction = Transaction.builder()
                .txId("11223344")
                .bankTxId("12345678")
                .result("SUCCESS")
                .build();
        transactionRepository.save(transaction);


        //when
        ResultActions resultActions = mvc.perform(
                get("/banking-api/transfer/11223341")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
        );

        //then
        resultActions
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("code").value("BANKING_ERROR_200"))
                .andExpect(jsonPath("message").value("잘못된 거래 ID"));
    }

    public void saveAccountOne() {
        Account account = Account.builder()
                .bankCode("D001")
                .bankAccountNumber("0123456789")
                .bankAccountId("00000001")
                .amount(50000000L)
                .build();
        accountRepository.save(account);
    }

    public void saveAccountTwo() {
        saveAccountOne();
        Account account = Account.builder()
                .bankCode("D002")
                .bankAccountNumber("9876543210")
                .bankAccountId("00000002")
                .amount(50000000L)
                .build();
        accountRepository.save(account);
    }
}
