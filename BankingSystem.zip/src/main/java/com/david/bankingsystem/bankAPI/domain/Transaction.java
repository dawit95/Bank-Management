package com.david.bankingsystem.bankAPI.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * FileName : Transaction
 * Author : David
 * Date : 2022-02-18
 * Description : Transaction 거래 성공 실패 내역
 */
@Getter
@NoArgsConstructor
@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String txId;

    @Column(nullable = false, unique = true)
    private String bankTxId;

    @Column(nullable = false)
    private String result;

    @Builder
    public Transaction(String txId, String bankTxId, String result) {
        this.txId =txId;
        this.bankTxId = bankTxId;
        this.result = result;
    }
}
