package com.david.bankingsystem.bankAPI.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileName : TransferIntoResponseDto
 * Author : David
 * Date : 2022-02-18
 * Description : TransferInto Response DTO
 */
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransferInfoResponseDto {
    private String result;
}
