package com.david.bankingsystem.bankAPI.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * FileName : AccountRepository
 * Author : David
 * Date : 2022-02-11
 * Description : Transaction Entity DB Layer accessor
 */
@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    Boolean existsByBankTxId(String bankTxId);

    Optional<Transaction> findByTxId(String txId);
//    Optional<Transaction> findByBankTxId(String bankTxId);
}
