package com.david.bankingsystem.bankAPI.service;

import org.springframework.stereotype.Service;

/**
 * FileName : BankService
 * Author : David
 * Date : 2022-02-18
 * Description : BankService
 */
@Service
public interface BankService {
    //계좌 등록
//    RegisterResponseDto registerAccount(Long userId, String bankCode, String bankAccountNumber);
    Object registerAccount(String bankCode, String bankAccountNumber);

    //계좌 이체
//    TransferResponseDto transferAccount(Long txId, String fromBankAccountId, String toBankCode, String toBankAccountNumber, String transferAmount);
    Object transferAccount(String txId, String fromBankAccountId, String toBankCode, String toBankAccountNumber, Long transferAmount);

    //거래 내역 확인
//    TransferInfoResponseDto transferInfo(String txId);
    Object transferInfo(String txId);

    //util
    String numberGenerator(int numLength);
}
