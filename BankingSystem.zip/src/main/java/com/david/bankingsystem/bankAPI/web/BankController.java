package com.david.bankingsystem.bankAPI.web;

import com.david.bankingsystem.bankAPI.dto.*;
import com.david.bankingsystem.bankAPI.service.BankServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * FileName : BankController
 * Author : David
 * Date : 2022-02-18
 * Description : 가상의 뱅킹시스템 Controller
 */
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/banking-api")
@RestController
public class BankController {
    private final BankServiceImpl bankService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequestDto requestDto) throws Exception {
        log.trace("/banking-api/register 계좌 등록 in Param : {}", requestDto);

        Object dto = bankService.registerAccount(
                requestDto.getBank_code(),
                requestDto.getBank_account_number()
        );

        if (dto.getClass().equals(ExceptionResponseDto.class)) {
            ExceptionResponseDto responseDto = (ExceptionResponseDto) dto;
            HttpStatus httpStatus;
            switch (responseDto.getCode()) {
                case "BANKING_ERROR_100":
                    httpStatus = HttpStatus.BAD_REQUEST;
                    break;
                case "BANKING_ERROR_101":
                    httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
                    break;
                default:
                    httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                    break;
            }
            return new ResponseEntity<>(responseDto, httpStatus);
        }
        log.debug("register 결과 보여줌 : {}", dto);
        return new ResponseEntity<>((RegisterResponseDto) dto, HttpStatus.OK);
    }

    @PostMapping("/transfer")
    public ResponseEntity<?> transfer(@RequestBody TransferRequestDto requestDto) throws Exception {
        log.trace("/banking-api/transfer 계좌 이체 in Param : {}", requestDto);
        Object dto = bankService.transferAccount(
                requestDto.getTx_id(),
                requestDto.getFrom_bank_account_id(),
                requestDto.getTo_bank_code(),
                requestDto.getTo_bank_account_number(),
                requestDto.getTransfer_amount()
        );

        if (dto.getClass().equals(ExceptionResponseDto.class)) {
            ExceptionResponseDto responseDto = (ExceptionResponseDto) dto;
            HttpStatus httpStatus;
            switch (responseDto.getCode()) {
                case "BANKING_ERROR_200":
                case "BANKING_ERROR_201":
                    httpStatus = HttpStatus.BAD_REQUEST;
                    break;
                case "BANKING_ERROR_202":
                case "BANKING_ERROR_203":
                    httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
                    break;
                default:
                    httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                    break;
            }
            return new ResponseEntity<>(responseDto, httpStatus);
        }
        log.debug("register 결과 보여줌 : {}", dto);
        return new ResponseEntity<>((TransferResponseDto) dto, HttpStatus.OK);
    }

    @GetMapping("/transfer/{txId}")
    public ResponseEntity<?> transferInfo(@PathVariable String txId) throws Exception {
        log.trace("/banking-api/transfer/{txId} 계좌거래 정보 조회 in Param : {}", txId);

        Object dto = bankService.transferInfo(txId);

        if (dto.getClass().equals(ExceptionResponseDto.class)) {
            ExceptionResponseDto responseDto = (ExceptionResponseDto) dto;
            HttpStatus httpStatus = responseDto.getCode().equals("BANKING_ERROR_200")?HttpStatus.BAD_REQUEST:HttpStatus.INTERNAL_SERVER_ERROR;
            return new ResponseEntity<>(responseDto, httpStatus);
        }
        log.debug("register 결과 보여줌 : {}", dto);
        return new ResponseEntity<>((TransferInfoResponseDto) dto, HttpStatus.OK);
    }
}
