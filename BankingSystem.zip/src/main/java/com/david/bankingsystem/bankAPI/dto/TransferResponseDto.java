package com.david.bankingsystem.bankAPI.dto;

import com.david.bankingsystem.bankAPI.domain.Transaction;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileName : TransferRequestDto
 * Author : David
 * Date : 2022-02-18
 * Description : Transfer Response DTO
 */
@Getter @Setter
@NoArgsConstructor
public class TransferResponseDto {
    private String tx_id;
    private String bank_tx_id;
    private String result;


    public TransferResponseDto(Transaction entity){
        this.tx_id = entity.getTxId();
        this.bank_tx_id = entity.getBankTxId();
        this.result = entity.getResult();
    }
}
