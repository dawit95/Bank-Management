package com.david.bankingsystem.bankAPI.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileName : TransferRequestDto
 * Author : David
 * Date : 2022-02-18
 * Description : Transfer Request DTO
 */
@Getter @Setter
@NoArgsConstructor
public class TransferRequestDto {
    private String tx_id;
    private String from_bank_account_id;
    private String to_bank_code;
    private String to_bank_account_number;
    private Long transfer_amount;

    @Builder
    public TransferRequestDto(String tx_id,
            String from_bank_account_id,
            String to_bank_code,
            String to_bank_account_number,
            Long transfer_amount){
        this.tx_id =tx_id;
        this.from_bank_account_id = from_bank_account_id;
        this.to_bank_code = to_bank_code;
        this.to_bank_account_number = to_bank_account_number;
        this.transfer_amount =transfer_amount;

    }
}
