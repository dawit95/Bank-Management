package com.david.bankingsystem.bankAPI.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileName : RegisterRequestDto
 * Author : David
 * Date : 2022-02-18
 * Description : Register Request DTO
 */
@Getter
@Setter
@NoArgsConstructor
public class RegisterRequestDto {
    private String bank_code;
    private String bank_account_number;

    @Builder
    public RegisterRequestDto(String bank_code, String bank_account_number){
        this.bank_code = bank_code;
        this.bank_account_number = bank_account_number;
    }
}
