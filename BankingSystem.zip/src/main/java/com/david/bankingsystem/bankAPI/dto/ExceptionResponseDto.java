package com.david.bankingsystem.bankAPI.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileName : ExceptionResponseDto
 * Author : David
 * Date : 2022-02-18
 * Description : Exception Response DTO
 */
@Getter @Setter
@NoArgsConstructor
public class ExceptionResponseDto {
    private String code;
    private String message;

    @Builder
    public ExceptionResponseDto(String code, String message){
        this.code =code;
        this.message =message;
    }
}
