package com.david.bankingsystem.bankAPI.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileName : RegisterResponseDto
 * Author : David
 * Date : 2022-02-18
 * Description : Register Response DTO
 */
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegisterResponseDto {
    private String bank_account_id;
}
