package com.david.bankingsystem.bankAPI.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * FileName : Account
 * Author : David
 * Date : 2022-02-11
 * Description : 사용자가 등록한 계좌 DB
 */
@Getter
@NoArgsConstructor
@Entity
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String bankCode;

    @Column(nullable = false)
    private String bankAccountNumber;

    @Column(nullable = false, unique = true)
    private String bankAccountId;

    @Column
    private Long amount ;


    @Builder
    public Account(String bankCode, String bankAccountNumber, String bankAccountId, Long amount) {
        this.bankCode = bankCode;
        this.bankAccountNumber = bankAccountNumber;
        this.bankAccountId = bankAccountId;
        this.amount = amount;
    }

    public void updateAmount(long amount){
        this.amount = amount;
    }

}
