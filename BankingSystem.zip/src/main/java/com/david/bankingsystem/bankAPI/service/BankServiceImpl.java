package com.david.bankingsystem.bankAPI.service;

import com.david.bankingsystem.bankAPI.domain.Account;
import com.david.bankingsystem.bankAPI.domain.AccountRepository;
import com.david.bankingsystem.bankAPI.domain.Transaction;
import com.david.bankingsystem.bankAPI.domain.TransactionRepository;
import com.david.bankingsystem.bankAPI.dto.ExceptionResponseDto;
import com.david.bankingsystem.bankAPI.dto.RegisterResponseDto;
import com.david.bankingsystem.bankAPI.dto.TransferInfoResponseDto;
import com.david.bankingsystem.bankAPI.dto.TransferResponseDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * FileName : AccountServiceImpl
 * Author : David
 * Date : 2022-02-11
 * Description : 계좌 관리에 필요한 service Interface 구현체
 */

@Slf4j
@RequiredArgsConstructor
@Service
public class BankServiceImpl implements BankService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;

    private static SecureRandom random;

    static {
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }


    @Transactional
    @Override
    public Object registerAccount(String bankCode, String bankAccountNumber) {
        if (!bankCode.equals("D001") && !bankCode.equals("D002") && !bankCode.equals("D003")) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_100")
                    .message("잘못된 계좌 정보")
                    .build();
        }

        try {
            Long number = Long.parseLong(bankAccountNumber);
        } catch (Exception e) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_101")
                    .message("등록할 수 없는 계좌")
                    .build();
        }

        if (accountRepository.existsByBankCodeAndBankAccountNumber(bankCode, bankAccountNumber)) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_101")
                    .message("등록할 수 없는 계좌")
                    .build();
        }

        //make AccountId
        String bankAccountId = createAccountId();

        try {
            Account account = Account.builder()
                    .bankCode(bankCode)
                    .bankAccountNumber(bankAccountNumber)
                    .bankAccountId(bankAccountId)
                    //계좌 금액 test를 위한 오천
                    .amount(50000000L)
                    .build();
            accountRepository.save(account);

            return new RegisterResponseDto(bankAccountId);

        } catch (Exception e) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_999")
                    .message("일시적으로 사용 불가")
                    .build();
        }
    }

    @Transactional
    @Override
    public Object transferAccount(
            String txId,
            String fromBankAccountId,
            String toBankCode,
            String toBankAccountNumber,
            Long transferAmount) {
        if (!accountRepository.existsByBankAccountId(fromBankAccountId)) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_200")
                    .message("등록되지 않은 계좌 ID")
                    .build();
        }

        if (!accountRepository.existsByBankCodeAndBankAccountNumber(toBankCode, toBankAccountNumber)) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_201")
                    .message("잘못된 계좌 정보")
                    .build();
        }
        Account fromAccount = accountRepository.findByBankAccountId(fromBankAccountId).orElse(new Account());
        Account toAccount = accountRepository.findByBankCodeAndBankAccountNumber(toBankCode, toBankAccountNumber).orElse(new Account());

        if (fromAccount.getAmount() < transferAmount) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_202")
                    .message("계좌 잔액 부족")
                    .build();
        }

        //make AccountId
        String bankAccountId = createBankTxId();

        try {
            fromAccount.updateAmount(fromAccount.getAmount() - transferAmount);
            toAccount.updateAmount(toAccount.getAmount() + transferAmount);
            accountRepository.save(fromAccount);
            accountRepository.save(toAccount);

            Transaction transaction = Transaction.builder()
                    .txId(txId)
                    .bankTxId(bankAccountId)
                    .result("SUCCESS")
                    .build();
            transactionRepository.save(transaction);

            return new TransferResponseDto(transaction);

        } catch (Exception e) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_999")
                    .message("일시적으로 사용 불가")
                    .build();
        }

    }

    @Override
    public Object transferInfo(String txId) {
        try {
            Transaction transaction = transactionRepository.findByTxId(txId).orElseThrow(() -> new RuntimeException());

            return new TransferInfoResponseDto(transaction.getResult());
        } catch (RuntimeException e) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_200")
                    .message("잘못된 거래 ID")
                    .build();
        } catch (Exception e) {
            return ExceptionResponseDto.builder()
                    .code("BANKING_ERROR_999")
                    .message("일시적으로 사용 불가")
                    .build();
        }
    }

    /**
     * 유일한 계좌 ID 생성
     *
     * @return 유일한 accountId string
     */
    public String createAccountId() {
        String accountId = numberGenerator(8);
        int cnt = 0;
        while (cnt < 20 && accountRepository.existsByBankAccountId(accountId)) {
            accountId = numberGenerator(8);
            //(timeout 같은 개념) 20번 시도후 불가능하면 Exception;
            cnt++;
            if (cnt == 20) {
                throw new RuntimeException("잠시후 다시 시도해 주세요!");
            }
        }
        return accountId;
    }

    /**
     * 유일한 txId 생성
     *
     * @return 유일한 txId string
     */
    public String createBankTxId() {
        String bankTxId = numberGenerator(8);
        int cnt = 0;
        while (cnt < 20 && transactionRepository.existsByBankTxId(bankTxId)) {
            bankTxId = numberGenerator(8);
            //(timeout 같은 개념) 20번 시도후 불가능하면 Exception;
            cnt++;
            if (cnt == 20) {
                throw new RuntimeException("잠시후 다시 시도해 주세요!");
            }
        }
        return bankTxId;
    }

    /**
     * 랜덤한 번호를 만든다.
     *
     * @param numLength 번호 길이
     * @return 만들어진 번호 string
     */
    @Override
    public String numberGenerator(int numLength) {
        //랜던 문자 길이
        StringBuilder randomStr = new StringBuilder();

        for (int i = 0; i < numLength; i++) {
            //0 ~ 9 랜덤 숫자 생성
            randomStr.append(random.nextInt(10));
        }
        log.debug("생성한 랜덤 계좌번호 : {}", randomStr);
        return randomStr.toString();
    }
}
